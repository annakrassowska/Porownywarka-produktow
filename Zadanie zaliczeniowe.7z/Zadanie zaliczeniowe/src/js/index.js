import "core-js/stable";
import "regenerator-runtime/runtime";


import Vue from "vue/dist/vue";


new Vue({
	el: "#app",
	data() {
		return {
            page: "products",
            searchName: "",
			searchModel: "",
            minPrice: "",
            maxPrice: "",
            showTab1: true,
            showTab2: false,
            filterStatus: 'all',        
            products: [],
            cart: []
        };
    },
    mounted(){
        fetch('http://localhost:3000/products')
        .then(response => response.json())
        .then(data => this.products = data)
        .catch(err => console.log(err.message))
    },

    methods: {       
        displayTab1(){
            this.showTab1 = true
            this.showTab2 = false
        },
        displayTab2(){
            this.showTab1 = false
            this.showTab2 = true
        },
        
        sortLowest() {
            this.products.sort((a,b)=> a.price > b.price ? 1: -1);
        },

        sortHighest() {
            this.products.sort((a,b)=> a.price > b.price ? -1: 1);
        },

        addItemToPage(product) {
            if((!this.cart.includes(product)) && (this.cart.length <3)){
                this.cart.push(product)
            }
        },
        removeItem(id) {
            this.cart.splice(id,1)
        },

        filteredCompany() {
           this.product.brand.value = "Company 1"
        },  
  
    },   

    watch: {
        cart(products) {
          localStorage.cart = products;
        }
      },
    computed: { 
        // WYSZUKIWARKA PO NAZWIE I NAZWIE MODELU
        filteredProducts: function() {
            return this.products.filter((product)=>{
                return product.name.toLowerCase().match(this.searchName.toLowerCase()) ||
                product.model.toLowerCase().match(this.searchName.toLowerCase())
            });
        },  
    }
})