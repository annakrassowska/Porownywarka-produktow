# Aplikacja

KOD ŹRÓDŁOWY - FOLDER ZADANIE ZALICZENIOWE.ZIP 
1.Rozpakować folder i otworzyć
2. Uruchomienie aplikacji:
npm install
npm install vue
npm i json-server -g
json-server --watch app/db.json